package com.example.library;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ReservedBookDao {

    @Insert
    void insert(ReservedBook book);

    @Delete
    void delete(ReservedBook book);

    @Query("SELECT * FROM reserved_books")
    List<ReservedBook> getAllReservedBooks();
}