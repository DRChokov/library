package com.example.library;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    BooksAdapter adapter;
    List<Book> bookList;

    Button btnViewReserved;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewBooks);
        btnViewReserved = findViewById(R.id.btnViewReserved);


        bookList = new ArrayList<>();
        bookList.add(new Book("1984", "George Orwell"));
        bookList.add(new Book("Brave New World", "Aldous Huxley"));
        bookList.add(new Book("Fahrenheit 451", "Ray Bradbury"));
        bookList.add(new Book("The Hobbit", "J.R.R. Tolkien"));
        bookList.add(new Book("To Kill a Mockingbird", "Harper Lee"));
        bookList.add(new Book("The Catcher in the Rye", "J.D. Salinger"));
        bookList.add(new Book("Naruto Vol. 1", "Masashi Kishimoto"));
        bookList.add(new Book("One Piece Vol. 1", "Eiichiro Oda"));
        bookList.add(new Book("Attack on Titan Vol. 1", "Hajime Isayama"));
        bookList.add(new Book("Death Note Vol. 1", "Tsugumi Ohba"));
        bookList.add(new Book("Fullmetal Alchemist Vol. 1", "Hiromu Arakawa"));
        bookList.add(new Book("Pride and Prejudice", "Jane Austen"));
        bookList.add(new Book("Moby-Dick", "Herman Melville"));
        bookList.add(new Book("The Great Gatsby", "F. Scott Fitzgerald"));
        bookList.add(new Book("The Alchemist", "Paulo Coelho"));
        bookList.add(new Book("The Name of the Wind", "Patrick Rothfuss"));

        adapter = new BooksAdapter(this, bookList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnViewReserved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ReservedBooksActivity.class);
                startActivity(intent);
            }
        });
    }
}