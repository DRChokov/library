package com.example.library;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;

public class ViewHolder extends RecyclerView.ViewHolder {
    TextView tvTitle, tvAuthor;
    Button btnDelete, btnShare;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);
        tvTitle = itemView.findViewById(R.id.tvBookTitle);
        tvAuthor = itemView.findViewById(R.id.tvBookAuthor);
        btnDelete = itemView.findViewById(R.id.btnDelete);
        btnShare = itemView.findViewById(R.id.btnShare);
    }
}
