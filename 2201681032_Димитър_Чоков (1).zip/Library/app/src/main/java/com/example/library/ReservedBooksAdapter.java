package com.example.library;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReservedBooksAdapter extends RecyclerView.Adapter<ReservedBooksAdapter.ViewHolder> {

    private List<ReservedBook> reservedBooks;
    private Context context;

    public ReservedBooksAdapter(Context context, List<ReservedBook> reservedBooks) {
        this.context = context;
        this.reservedBooks = reservedBooks;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.reserved_book_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReservedBook book = reservedBooks.get(position);
        holder.tvTitle.setText(book.getTitle());
        holder.tvAuthor.setText(book.getAuthor());

        holder.btnDelete.setOnClickListener(v -> {
            AppDatabase.getInstance(context).reservedBookDao().delete(book);
            reservedBooks.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, reservedBooks.size());
        });

        holder.btnShare.setOnClickListener(v -> {
            String shareText = "Чета книгата: \"" + book.getTitle() + "\" от " + book.getAuthor();
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
            context.startActivity(Intent.createChooser(shareIntent, "Сподели книга чрез"));
        });
    }

    @Override
    public int getItemCount() {
        return reservedBooks.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvAuthor;
        Button btnDelete, btnShare;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvBookTitle);
            tvAuthor = itemView.findViewById(R.id.tvBookAuthor);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnShare = itemView.findViewById(R.id.btnShare);
        }
    }
}
