package com.example.library;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;

public class ReservedBooksActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ReservedBooksAdapter adapter;
    List<ReservedBook> reservedBooks;
    Button btnBackToMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserved_books);

        recyclerView = findViewById(R.id.recyclerViewReservedBooks);
        btnBackToMenu = findViewById(R.id.btnBackToMenu);

        AppDatabase db = AppDatabase.getInstance(this);
        reservedBooks = db.reservedBookDao().getAllReservedBooks();

        if (reservedBooks.isEmpty()) {
            Toast.makeText(this, "Няма резервирани книги", Toast.LENGTH_SHORT).show();
        }

        adapter = new ReservedBooksAdapter(this, reservedBooks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);


        btnBackToMenu.setOnClickListener(v -> {
            finish();
        });
    }
}
