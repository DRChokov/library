package com.example.library;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "reserved_books")
public class ReservedBook {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String author;

    public ReservedBook(String title, String author){
        this.title = title;
        this.author = author;
    }

    public void setId(int id){
        this.id = id;
    }

    public int getId(){
        return id;
    }

    public String getTitle(){
        return title;
    }

    public String getAuthor(){
        return author;
    }
}